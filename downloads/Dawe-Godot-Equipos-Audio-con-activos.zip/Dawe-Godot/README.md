# Dawe — prototipo de shooter en Godot 4

**Godot es el motor principal del proyecto.** La escena de arranque está en [`godot/project.godot`](godot/project.godot). El prototipo tiene movimiento local, primera y tercera persona, SAS y Phoenix, y los modelos de primera persona de USP-S, AK-47 y bayoneta. Los modelos de arma reproducen animaciones; todavía no hay balística, daño, bots ni multijugador.

## Descargar el proyecto con los activos incluidos

**[Descargar Dawe para Godot con modelos y texturas (.zip)](downloads/Dawe-Godot-Equipos-Audio-con-activos.zip?raw=true)**

El ZIP contiene el proyecto y los activos preparados de Dust II, SAS, Phoenix, la USP-S, la AK-47 y la bayoneta con el brazo cromado de Silverhand y el implante de la mano derecha del MultiRig. Extraé todo, abrí `godot/project.godot` con Godot 4.5 o posterior, esperá a que se importen los recursos y presioná **F5**. No hace falta ejecutar los scripts de importación para usar el ZIP.

## Abrir el proyecto

Abrí `godot/project.godot` con **Godot 4.5 o posterior** y presioná **F6** desde `main.tscn` o **F5** desde el proyecto. Sin importar recursos de terceros, funciona la pista local con figuras de reemplazo: un patio, un paso angosto y una rampa que permite probar el movimiento y la cámara.

| Control | Acción |
| --- | --- |
| WASD / ratón | Mover / mirar |
| Shift / Ctrl / Espacio | Correr / agacharse / saltar |
| M | Abrir el selector de equipos con logos (CT/SAS o T/Phoenix); se abre también al iniciar |
| 1 / 2 / 3 / rueda | AK-47 / USP-S / bayoneta / recorrer armas disponibles |
| G / E | Soltar el arma equipada / recoger y equipar la más cercana al alcance |
| V | Alternar entre primera y tercera persona |
| Clic izquierdo / R / F | Disparo o tajo con la bayoneta / recarga / inspección (con bayoneta, F durante el desenfunde reproduce la variante) |
| Clic derecho | Quitar o colocar el silenciador en la USP-S (también T) o reproducir la estocada con bayoneta |
| Tab / Retroceso / Escape | Mostrar radar con posición y rumbo / volver al inicio / liberar el ratón |

## Salto, escalones y agarre

- SAS y Phoenix muestran despegue, descenso y aterrizaje en tercera persona. Las poses se generan para las tres posturas de arma y no empujan el cuerpo físico.
- El salto conserva el impulso y permite alcanzar repisas más altas. Los escalones de hasta 34 cm se suben caminando si hay una superficie transitable y espacio para la cápsula. No se quitan las paredes ni los límites invisibles de Dust II.
- Los dedos de la mano derecha se ajustan a la forma de cada empuñadura antes del horneado. Los clips mantienen el agarre estabilizado durante el disparo.

## Instalar los activos locales

Para reconstruir los activos preparados que incluye el ZIP, el importador descarga las **revisiones fijadas** de cs2go y MultiRig y deja un inventario con sus SHA-256. Revisá las [notas de procedencia y licencias](docs/godot-migration.md#procedencia-y-límites-de-uso) antes de compartir cualquier derivado.

Desde la raíz, con **Python 3.10+**, Node.js y [Basis Universal](https://github.com/BinomialLLC/basis_universal) (`basisu` 1.16+ con KTX2):

```sh
python3 tools/import_assets.py             # omitilo si ya tenés el inventario actualizado
npm ci --prefix tools/agent_assets
python3 -m pip install numpy Pillow soundfile         # en tu entorno virtual
python3 tools/build_godot_assets.py --basisu /ruta/basisu
```

Esto genera `godot/generated/` con la **malla de Dust II**, su **colisión independiente**, radar y navegación de referencia. El nivel arranca frente a **Puertas Largas**. También genera **SAS y Phoenix**, cada uno con la pose base y los **36 ciclos** disponibles. Si `godot/generated/` ya existe, el generador no lo pisa: conservá una copia y armá uno nuevo, o elegí otro destino con `--output`.

Para sumar los modelos de primera persona, con **Blender 4.5+** (con Cycles habilitado):

```sh
for weapon in usp-s ak-47 bayonet; do
  blender --background --python-exit-code 1 --python tools/build_godot_viewmodel.py -- \
    --weapon "$weapon" --output "third_party_assets/${weapon}_bake"
  python3 tools/port_godot_viewmodel.py --weapon "$weapon" \
    --smd "third_party_assets/${weapon}_bake"
done
python3 tools/import_presentation.py        # logos y sonidos locales, incluye viento de síntesis
python3 tools/build_weapon_drops.py         # mallas de suelo a partir de los GLB anteriores
```

Se hornea el material por capas del brazo Silverhand y el implante del MultiRig para Godot. Se conserva la geometría original de brazos y arma, hasta cuatro pesos por vértice y los mapas de color, rugosidad/metalizado y normales que trae cada modelo, **sin compilar MDL ni BSP**. Cada arma entra como GLB con su esqueleto y el conjunto de clips disponible: **7 para USP-S**, incluido montar/desmontar el silenciador, **5 para AK-47** y **8 para la bayoneta** (dos reposos, desenfunde, dos tajos, estocada y dos inspecciones). Abrí o volvé a importar el proyecto y dejá terminar la importación de Godot antes de ejecutarlo. Para forzar la pista local aun con Dust II instalado: `godot --path godot -- --training`.

## Vista texturizada de Puertas Largas

La demo de Arena muestra un recorte de la **malla visual texturizada** de Dust II sobre la colisión real. Arranca con el selector CT/T con sus logos. `V` muestra los brazos y el arma en primera persona. `1` / `2` / `3` equipan la AK-47, la USP-S y la bayoneta. `G` deja el arma física en el suelo y `E` la recoge desde cerca; si soltás las tres, quedás con las manos vacías. Los materiales y las animaciones se generan de los GLB preparados arriba, que están incluidos en el ZIP de `downloads/`. El ZIP para escritorio no duplica los GLB de armas ni agentes como `.vis`: Godot usa los GLB importados. El recorte y las armas de suelo sí incluyen sus propios `.vis`. El archivo automático de fuentes de GitHub es distinto.

Para reproducir ese recorte en Godot, después de generar `dust2.glb` y los cinco GLB de agentes y armas:

```sh
python3 tools/build_godot_preview.py
godot --path godot -- --visual-preview
```

El generador crea paquetes `.vis` en `godot/generated/`, que el juego también puede leer sin importar los GLB en el editor. Conservan la malla, las texturas, los esqueletos y los clips de esta demo, incluidos los mapas de normales, metalizado, rugosidad y oclusión de las armas. Fuera del recorte texturizado, el mapa sigue en modo de diagnóstico; el arranque habitual usa el Dust II visual completo cuando su GLB ya fue importado.

## Recorrer Puertas Largas con la colisión real

El modo de diagnóstico muestra **la misma geometría física que usa el controlador**, sin depender de importar las texturas, los agentes ni el modelo visual en el editor. Usa una malla simplificada en apariencia, no en colisión. La preparación normal ya genera el archivo; si tenés un `godot/generated/` de la versión anterior:

```sh
python3 tools/build_dust2_collision.py
# Abrir en el patio de Puertas Largas, con radar en Tab.
godot --path godot -- --collision-preview
```

El recorrido verificado pasa por las dos puertas, rodea Larga hasta la bajada, entra al foso, vuelve por la pendiente y sigue hasta la rampa de A. Se puede caminar todo ese trayecto sin saltar. Esto no reemplaza la importación visual completa descrita arriba.

## Pruebas

```sh
# Verificar el paquete generado sin abrir el editor
python3 tools/check_godot_assets.py --quality-viewmodels

# Importar una vez y ejecutar las pruebas con Godot desde la terminal
# (usar godot4 en lugar de godot si así se llama tu ejecutable)
godot --headless --path godot --import
godot --headless --path godot --script res://tests/smoke.gd -- --training
godot --headless --path godot --script res://tests/smoke.gd -- --require-assets
godot --headless --path godot --script res://tests/smoke.gd -- --require-preview
godot --headless --path godot --script res://tests/dust2_route.gd -- --collision-preview
```

La prueba de la pista comprueba paredes, rampas, agachado con transición de cámara, salto, frenado, control aéreo y la tolerancia del salto al aterrizar o dejar un borde. También verifica cinco escalones, un salto a una repisa de 94 cm y que la cámara se retraiga al rozar una esquina. La prueba de Dust II recorre además la escalera real de Corta en ambas direcciones. `dust2_route.gd` usa el mismo controlador e input de movimiento que el jugador en la malla física: no teletransporta entre puntos. La prueba con activos comprueba el punto inicial de Dust II, que se cargue la geometría de colisión, los materiales, los bancos de animación, el cambio de pose de los huesos y el agarre de ambas manos durante el retroceso, la rueda para cambiar de arma y la visibilidad del silenciador antes y después de sus eventos. También verifica los logos y el bloqueo del menú, los accesos 1/2/3, las señales de audio y el ciclo de tirar y recuperar la USP-S con su estado de silenciador. `--require-preview` comprueba además el recorte texturizado de la demo.

## Más información

- [Decisiones de la migración y trabajo pendiente](docs/godot-migration.md)
- [Guía histórica de Xash3D](docs/xash3d.md) y [reconstrucción BSP de Puertas Largas](docs/dust2-long.md). No son dependencias del proyecto Godot.
