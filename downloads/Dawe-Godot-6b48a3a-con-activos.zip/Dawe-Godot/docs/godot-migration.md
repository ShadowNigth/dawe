# Migración a Godot 4

## Qué se reutilizó

- **Dust II:** el importador toma los GLB visual y físico de cs2go. Conserva las 691 primitivas visuales, las 564 imágenes y las 37 mallas físicas. Quita Meshopt y cuantización mediante decodificación, traduce KTX2 a PNG y divide la malla visual en grupos de superficies para importarla. Conserva metros y eje Y arriba; el cuerpo usa la colisión original transformada a coordenadas del mundo. No convierte el BSP plano de Xash3D ni crea colisión a partir de los detalles visuales. El radar indica posición y rumbo mediante la proyección de la vista nativa; la navegación se conserva como referencia, sin IA.
- **SAS/Phoenix:** se usa el skin original con sus pesos, no el MDL de pesos rígidos. Los 36 ciclos se retargetean por nombre y jerarquía, se muestrean a 30 fps y mantienen la raíz fija. `idle` es la pose base, no un reposo extraído; al detenerse durante el recorrido se congela una pose armada de la marcha. El controlador elige la diagonal vecina para las direcciones cardinales; las poses de cuchillo quedan importadas aunque no hay cuchillo seleccionable.
- **USP-S/AK-47:** se reutiliza el retargeting de las manos del MultiRig y el horneado de las piezas móviles. Se convierte el intermedio SMD del exportador existente directamente a GLB, en metros y orientado a la cámara de Godot. Sigue usando la malla y los pesos rígidos de esa versión del rig, por lo que pueden persistir pliegues o contactos imperfectos. El silenciador conserva los tiempos de visibilidad en el JSON lateral. El arma de primera persona usa un viewport independiente para no intersectar las paredes del nivel.
- **Movimiento local:** `CharacterBody3D` con aceleración/frenado, gravedad, salto, ajuste al piso, agachado con comprobación de espacio al incorporarse y cámara exterior con barrido esférico (más un rayo central). El barrido evita que el volumen alrededor de la cámara atraviese los cantos cuando su centro todavía está libre. No pretende reproducir exactamente GoldSrc; todavía no hay soporte específico para escaleras de mano ni para subir peldaños altos.

## Límites visuales y de juego

El escenario es el **export estático** de Dust II, no un port completo de CS2. No se replican los shaders ni los datos de iluminación del cliente de cs2go (incluidos canales de color auxiliares, sondas y efectos especiales). Las texturas del mapa se reducen a 256 px por lado de forma predeterminada; `--texture-size` permite cambiarlo si hay memoria disponible. Las puertas dinámicas, objetos rompibles, lógica de sitios, audio y reglas de ronda no están implementados. Las armas sólo se ven en primera persona; no hay armas acopladas a los agentes. El recorrido físico de Puertas Largas, el foso y la rampa de A ya está comprobado. La integración se comprobó en el recorte del navegador. Falta revisar la apariencia del mapa completo en el editor de escritorio y conectar las animaciones a munición y a un campo de tiro local.

## Vista texturizada en el navegador

La demo incluye el patio exterior, el paso bajo los arcos y el entorno de la salida de Puertas Largas. `tools/build_godot_preview.py` toma las superficies visuales del recorte a escala real, hornea el ajuste UV de cada material, conserva los PNG con alfa y usa la misma colisión que el modo de diagnóstico. Los paquetes `.vis` contienen datos preparados para `ArrayMesh`, `Skeleton3D`, `Skin` y `AnimationPlayer`: sirven para la demo sin el importador de glTF del editor. El modo de escritorio sigue dando prioridad a las escenas importadas de los GLB originales si están disponibles.

El recorte usa texturas base, opacidad y recorte alfa, no todos los mapas PBR ni los shaders de origen. Incluye las dos mallas de agente y sus 36 ciclos por personaje, y los modelos de primera persona de USP-S y AK-47 con las manos y sus clips. No se agregaron armas en tercera persona ni disparos con daño.

## Prueba de Puertas Largas, foso y rampa de A

`tools/build_dust2_collision.py` transforma las caras de `dust2-physics.glb` a coordenadas del mundo, las separa en celdas espaciales de 12 m sin recortar los triángulos y distingue los límites invisibles de jugador. Los límites siguen siendo sólidos para el personaje, pero no aparecen como paredes en la vista de diagnóstico ni bloquean la cámara. Los triángulos degenerados no se agregan. El modo de escritorio usa este mismo archivo si está disponible y conserva la importación del GLB físico como compatibilidad con paquetes antiguos.

`godot/tests/dust2_route.gd` conduce al personaje a partir de puntos tomados de la navegación de cs2go. Pasa las dos puertas, baja hasta aproximadamente **−4,56 m**, vuelve a Larga y alcanza la rampa de A a **+1,69 m**. No requiere saltos ni comprobaciones visuales subjetivas para validar el trayecto; no llega hasta la plataforma del sitio ni valida el resto del mapa. La opción `--collision-preview` conserva el modo anterior, con las superficies físicas sombreadas y una cuadrícula.

## Procedencia y límites de uso

- **cs2go:** [`3kh0/cs2go`](https://github.com/3kh0/cs2go), revisión `7cce816747b11d6eb26b2f4ece8b68ccc740c5eb`. El proyecto de terceros no está afiliado a Valve; sus archivos de CS2 no se deben considerar redistribuibles por el solo hecho de estar publicados en GitHub. Las marcas y los activos correspondientes pertenecen a sus titulares.
- **Cyberpunk2077-MultiRig:** [`goribby/Cyberpunk2077-MultiRig`](https://github.com/goribby/Cyberpunk2077-MultiRig), revisión `e028a5dadc9c215d46258aba57fb9da7d57556cd`. Rig de Goribby, mallas y texturas de CD Projekt Red. Consultá el README del rig y sus restricciones de uso, incluida la restricción comercial. Para distribuir Dawe se necesitan activos propios o licenciados, además de conservar las atribuciones aplicables.
- `third_party_assets/`, `godot/generated/` y `godot/.godot/` no van a Git. El proyecto base arranca con geometría y figuras propias sin los archivos de terceros.
